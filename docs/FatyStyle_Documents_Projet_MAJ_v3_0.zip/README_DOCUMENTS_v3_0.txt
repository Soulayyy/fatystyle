Pack documents Faty Style v3.0
Aligné sur le site de recette http://178.105.180.143:8082/index.html
Contient : cahier des charges, spécifications fonctionnelles, spécifications techniques, guide utilisateur, suivi charges/chiffrage, template recette simple.
